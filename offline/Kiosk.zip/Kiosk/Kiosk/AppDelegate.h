//
//  AppDelegate.h
//  Kiosk
//
//  Created by Trevor on 2/29/16.
//  Copyright © 2016 Trevor. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

