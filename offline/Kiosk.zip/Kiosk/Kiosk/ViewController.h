//
//  ViewController.h
//  Kiosk
//
//  Created by Trevor on 2/29/16.
//  Copyright © 2016 Trevor. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UIWebViewDelegate>

@property (nonatomic, strong) UIWebView *webView;


@end

