//
//  ViewController.m
//  Kiosk
//
//  Created by Trevor on 2/29/16.
//  Copyright © 2016 Trevor. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];


    
    
    
    
    /*
     
        WELCOME!
     
     
     you only need to change this one line, the url.
     
     it should look like this:
     
     
     
     NSString *myURL = @"http://kiosk.imax.earth";
     
     
     
     that whole underlined part, the url itself, can change.. but keep the quotation marks and everything else.
     
     (if for some reason you want to change something else, scroll down a bit)
    
     */
    
    
    NSString *myURL = @"http://kiosk.imax.earth";
    
    
    
    
    /*
     you don't need to read this line
     */
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    self.webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    self.webView.autoresizesSubviews = YES;
    self.webView.autoresizingMask=(UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth);
    
    //set the web view delegates for the web view to be itself
    [self.webView setDelegate:self];
    
    [self.view addSubview:self.webView];
    
    self.webView.scrollView.bounces = NO;
                    
    
    
    NSURLRequest *thisRequest = [NSURLRequest requestWithURL:[NSURL URLWithString:myURL]];
    [self.webView loadRequest:thisRequest];
    
    NSError *error;
    
    NSData *d = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:myURL] options:NSDataReadingUncached error:&error];
    
    if (error || d == nil || [d length] == 0)
    {
        UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"Error"
                                                                       message:@"No internet connection. Please check your connection settings and try again."
                                                                preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                              handler:^(UIAlertAction * action) {}];
        
        [alert addAction:defaultAction];
        [self presentViewController:alert animated:YES completion:nil];
    }
    
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (BOOL) prefersStatusBarHidden {
    return YES;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
